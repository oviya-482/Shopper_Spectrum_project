# 🛒 Shopper Spectrum: Customer Segmentation & Product Recommendations

## Contents
- `Shopper_Spectrum.ipynb` — full analysis notebook: data cleaning, EDA, RFM feature
  engineering, KMeans clustering (elbow + silhouette evaluation), and the item-based
  collaborative filtering recommendation engine. Already executed, with all plots and
  outputs baked in.
- `streamlit_app/` — the Streamlit web app and the trained model artifacts it needs:
  - `app.py`
  - `kmeans_model.pkl`, `scaler.pkl`, `cluster_label_map.pkl` (segmentation model)
  - `product_similarity.pkl`, `product_list.pkl` (recommendation engine)
  - `requirements.txt`

## Running the Streamlit app

```bash
cd streamlit_app
pip install -r requirements.txt
streamlit run app.py
```

The app has two tabs:
1. **Product Recommendations** — pick a product, get the 5 most similar products.
2. **Customer Segmentation** — enter Recency / Frequency / Monetary values, get the
   predicted customer segment (High-Value, Regular, Occasional, At-Risk).

## Re-running the notebook on your own data

Place `online_retail.csv` in the same folder as `Shopper_Spectrum.ipynb` and run all
cells top to bottom. The final cells re-save the five `.pkl` artifacts used by the app.

## Methodology summary

- **Cleaning:** dropped rows with missing `CustomerID`, removed cancelled invoices
  (`InvoiceNo` starting with `C`), removed non-positive quantities/prices, and
  de-duplicated exact duplicate rows.
- **RFM:** Recency = days since last purchase (relative to one day after the dataset's
  last transaction), Frequency = number of distinct invoices, Monetary = total spend.
- **Clustering:** RFM values standardized with `StandardScaler`, then KMeans with
  k=4 (chosen via the elbow curve, silhouette score, and the business requirement for
  4 named segments). Clusters are ranked on their RFM averages and mapped to
  High-Value / Regular / Occasional / At-Risk.
- **Recommendations:** a Customer × Product quantity matrix is built, transposed to
  Product × Customer, and cosine similarity is computed between products. The top-5
  most similar products are returned for any product a user selects.
